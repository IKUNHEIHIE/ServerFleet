# Server Fleet G1 评审交付包

产品基线：v0.9/docs-r2（不修改）。状态：**架构评审草案；待项目所有者确认**。

- `G1-Architecture-Review.md`：技术栈对照、架构冲突、实现模型权衡、PoC 与 G2 边界。
- `ADR-Change-Proposals.md`：三组需更新/解释的 ADR 提案，不会自动替代已有已批准条款。
- `G1-Decision-Sheet.md`：G1-D1～D6 逐项审批清单。

**不包含**：任何代码实现、真实插件二进制、API 契约变更、新功能原型修改。正式旧 ADR 应在后续审批完成时由单独修订文件保留 supersedes 信息。
