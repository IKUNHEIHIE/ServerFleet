# Server Fleet API 契约范围说明（产品原型 v0.2）

本项目目前在**产品功能规划阶段**。此前未随交互 HTML 原型交付可单独维护的 API 规范，因此本次创建 `Server-Fleet-API-Contract-v0.2.yaml` 作为**未来实现使用的拟议 OpenAPI 3.1 契约**；目前**没有任何后端服务或真实 API 可调用**。

## 当前已细化的接口：文件互传（FR-FT-001）

| 用户界面操作 | 拟议 API | 状态 |
|---|---|---|
| 选择源/目标节点 | `GET /api/v1/nodes` | 新增契约草案 |
| 浏览目录、当前目录搜索、分页 | `GET /api/v1/nodes/{nodeId}/files` | 新增契约草案 |
| 计算目录体积 | `POST /api/v1/nodes/{nodeId}/files/size` | 新增契约草案 |
| 创建文件夹 | `POST /api/v1/nodes/{nodeId}/files/directories` | 新增契约草案 |
| 重命名 | `PATCH /api/v1/nodes/{nodeId}/files/rename` | 新增契约草案 |
| 删除 | `DELETE /api/v1/nodes/{nodeId}/files` | 新增契约草案 |
| 本机上传：开启会话 | `POST /api/v1/nodes/{nodeId}/files/uploads` | 新增契约草案 |
| 上传：完成并校验 | `POST /api/v1/nodes/{nodeId}/files/uploads/{uploadId}/complete` | 新增契约草案 |
| 双向传输确认 | `POST /api/v1/transfers` | 新增契约草案 |
| 查询任务列表、状态与进度 | `GET /api/v1/transfers`、`GET /api/v1/transfers/{transferId}` | 新增契约草案 |
| 取消任务 | `POST /api/v1/transfers/{transferId}/cancel` | 新增契约草案 |

**接口与前端差异说明**：原型只使用本地状态，没有向上述端点发送 HTTP 请求。实际上传会话、文件数据通道、下载方式、签名校验、权限校验、恢复中断等属于后续实现细化。本版不承诺具体传输协议或存储实现。

## 尚未展开为完整 OpenAPI 的既有功能模块

概览、节点注册与身份、分组、批量任务、监控告警、工作流、插件、AI 助手、Cloudflare DNS、入口节点、证书、更新、备份、用户权限、审计日志及系统设置均在既有原型中，但**其后端接口仍待逐模块定义**。不应把这些界面展示的数据字段当作已经批准的服务接口。

## 预期的 API 安全和可靠性约束

- 每个操作都验证身份和资源级权限；`file.transfer` 同时验证源读取权限和目标写入权限。
- 所有路径使用**绝对路径**并按节点系统规则规范化；防止 `..` 越界、符号链接绕过、目录遍历。
- 批量传输按异步任务响应，包含项目级失败详情；使用幂等键防止重复提交。
- 高风险删除/覆盖和系统目录需细粒度授权；调用和结果需审计。
- 以可取消任务呈现传输进度，但对“部分已写入文件”的清理规则待产品决策。

## 变更记录

- **v0.2 / FR-FT-001**：核心功能新增「文件互传」，建立与对应 HTML 原型同步的文件管理及传输 API 契约草案。
