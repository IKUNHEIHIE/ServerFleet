# Server Fleet v0.3 · 交互前端与产品文档

## 快速查看

1. 双击 `ServerFleet-v0.3.html`，用 Chrome 或 Edge 打开。
2. 左侧依次打开「网关管理」「DNS 管理」，查看重新命名的模块。
3. 打开「系统设置 → DNS 供应商」，可以创建多个 Cloudflare 演示账号、设默认、启停等。
4. 返回「DNS 管理」，切换账号、添加演示域名以及在其下编辑演示 DNS 记录。

**不需安装 Node、Python 或任何依赖。整个前端是离线单 HTML。**

## 交付文件

- `ServerFleet-v0.3.html`：可交互单文件前端
- `Server-Fleet-功能需求文档-v0.3.md`：产品功能范围（包括 v0.2 文件互传全部规则）
- `Server-Fleet-API-Contract-v0.3.yaml`：拟议 OpenAPI 3.1 契约
- `Server-Fleet-API-说明-v0.3.md`：接口范围说明
- `CHANGELOG-v0.3.md`：变更记录

## 演示与安全边界

前端仅在当前浏览器中保存模拟节点、文件、账号与解析记录。没有真实服务器连接或供应商 API 请求。Cloudflare API Token 表单在原型中禁用，**请勿输入真实密钥**。

v0.3 保留 v0.2 使用的本地数据命名空间，允许迁移旧 DNS 示例记录；如果希望从头体验，请使用侧栏底部「重置演示数据」。

目前仍是产品功能规划阶段，不代表已完成真实后端开发；已批准的架构 ADR 不受此次命名调整影响。
