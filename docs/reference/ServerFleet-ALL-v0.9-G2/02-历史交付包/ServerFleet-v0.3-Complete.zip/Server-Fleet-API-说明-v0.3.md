# Server Fleet API 契约范围说明（产品原型 v0.3）

本项目目前在**产品功能规划阶段**。此前未随交互 HTML 原型交付可单独维护的 API 规范，因此现维护 `Server-Fleet-API-Contract-v0.3.yaml` 作为**未来实现使用的拟议 OpenAPI 3.1 契约**；目前**没有任何后端服务或真实 API 可调用**。

## 当前已细化的接口：文件互传（FR-FT-001）

| 用户界面操作 | 拟议 API | 状态 |
|---|---|---|
| 选择源/目标节点 | `GET /api/v1/nodes` | 新增契约草案 |
| 浏览目录、当前目录搜索、分页 | `GET /api/v1/nodes/{nodeId}/files` | 新增契约草案 |
| 计算目录体积 | `POST /api/v1/nodes/{nodeId}/files/size` | 新增契约草案 |
| 创建文件夹 | `POST /api/v1/nodes/{nodeId}/files/directories` | 新增契约草案 |
| 重命名 | `PATCH /api/v1/nodes/{nodeId}/files/rename` | 新增契约草案 |
| 删除 | `DELETE /api/v1/nodes/{nodeId}/files` | 新增契约草案 |
| 本机上传：开启会话 | `POST /api/v1/nodes/{nodeId}/files/uploads` | 新增契约草案 |
| 上传：完成并校验 | `POST /api/v1/nodes/{nodeId}/files/uploads/{uploadId}/complete` | 新增契约草案 |
| 双向传输确认 | `POST /api/v1/transfers` | 新增契约草案 |
| 查询任务列表、状态与进度 | `GET /api/v1/transfers`、`GET /api/v1/transfers/{transferId}` | 新增契约草案 |
| 取消任务 | `POST /api/v1/transfers/{transferId}/cancel` | 新增契约草案 |

**接口与前端差异说明**：原型只使用本地状态，没有向上述端点发送 HTTP 请求。实际上传会话、文件数据通道、下载方式、签名校验、权限校验、恢复中断等属于后续实现细化。本版不承诺具体传输协议或存储实现。

## v0.3 新增契约：DNS 管理（FR-DNS-001）

- `GET /api/v1/dns/providers`：列出支持的供应商及能力（首版仅 `cloudflare`）。
- `GET/POST /api/v1/dns/accounts`：查看/创建 DNS 账号，创建时向受保护的后端提交 API Token。
- `GET/PATCH/DELETE /api/v1/dns/accounts/{accountId}`：账号详情、编辑、解除绑定；返回值不包含明文凭证。
- `PUT /api/v1/dns/accounts/{accountId}/credentials`：轮换 Token。
- `PUT /api/v1/dns/accounts/{accountId}/default`：设置默认账号。
- `POST /api/v1/dns/accounts/{accountId}/test`：验证连接和最小权限。
- `GET /api/v1/dns/accounts/{accountId}/zones`、`POST /api/v1/dns/accounts/{accountId}/zones/sync`：读取/同步已授权 Zone；不在真实产品中靠演示按钮创建 Cloudflare Zone。
- `GET/POST /api/v1/dns/zones/{zoneId}/records`、`PATCH/DELETE /api/v1/dns/zones/{zoneId}/records/{recordId}`：按 Zone 操作记录。

账号、Zone、记录按真实归属进行授权隔离。Cloudflare 独有的代理标志按供应商能力处理，不能变成所有 DNS 平台的强制字段。v0.3 前端不采集或保存真实 API Token，不做真实连接检查。

## v0.3 网关命名与接口草案（FR-GW-001）

`GET /api/v1/gateways` 返回既定的 4 台 Nginx 应用网关；`GET/POST /api/v1/gateway-routes`、`PATCH/DELETE /api/v1/gateway-routes/{routeId}` 为现有页面的服务路由操作建立初步契约。未改变既有架构 ADR，未将其扩展为系统网络网关或全功能 API Gateway。

## 尚未展开为完整 OpenAPI 的既有功能模块

概览、节点注册与身份、分组、批量任务、监控告警、工作流、插件、AI 助手、证书、更新、备份、用户权限、审计日志和系统设置的**其他功能**仍待逐模块细化；DNS 与网关接口也只是初步草案。不应把这些界面展示的数据字段当作已经批准的服务接口。

## 预期的 API 安全和可靠性约束

- 每个操作都验证身份和资源级权限；`file.transfer` 同时验证源读取权限和目标写入权限。
- 所有路径使用**绝对路径**并按节点系统规则规范化；防止 `..` 越界、符号链接绕过、目录遍历。
- 批量传输按异步任务响应，包含项目级失败详情；使用幂等键防止重复提交。
- 高风险删除/覆盖和系统目录需细粒度授权；调用和结果需审计。
- 以可取消任务呈现传输进度，但对“部分已写入文件”的清理规则待产品决策。

## 变更记录

- **v0.2 / FR-FT-001**：核心功能新增「文件互传」，建立与对应 HTML 原型同步的文件管理及传输 API 契约草案。

- **v0.3 / FR-GW-001 / FR-DNS-001**：统一「网关管理」「DNS 管理」命名，新增 DNS 供应商账号、Cloudflare Zone 与记录草案及网关路由契约。
