# Server Fleet v0.4 — 离线交互式产品原型

## 启动

解压后直接双击 `ServerFleet-v0.4.html`，或在 Chrome / Edge 中打开；无需 npm、Node、网络、后端或数据库。界面逻辑和数据均在浏览器本地模拟。浏览器 localStorage 将保存操作数据，使用左下角“重置演示数据”可恢复。

## v0.4 值得尝试的交互

1. 左侧展开/折叠「节点管理」：节点列表、添加节点、分组管理；查看节点表的地区国旗。
2. 点击「系统设置 → 通知设置」：模拟配置 SMTP/QQ、开关、测试和查看记录。**不要输入真实凭证。**
3. 点击「网关管理 → 新建网关」：选在线节点，勾选授权确认，创建模拟安装任务；分别尝试失败、重试、检查通过、进入维护。
4. 点击「插件中心 → 仓库配置」：选择官方仓库或 Fork（示例 URL `https://github.com/developer/server-fleet`）；选择插件，授权模拟安装、热禁用/启用、更新失败保留旧版、卸载，观察侧边菜单变化。
5. 继续尝试原有文件互传（宝塔式双栏）、多 Cloudflare 账号与 DNS、AI 运维等功能。

## 文件清单

- `ServerFleet-v0.4.html`：完整单文件可交互前端。
- `ServerFleet-Functional-Requirements-v0.4.md`：功能与验收规则。
- `ServerFleet-API-Contract-v0.4.yaml`：OpenAPI 3.1 后端契约草案。
- `CHANGELOG-v0.4.md`：变更历史。
- `Plugin/`：仓库目录与插件清单/manifest 样例，**无可执行插件、无需安装**。

## 重要边界

这是产品功能演示，所有安装、推送、更新和文件传输均为模拟。不存在远程节点连接、QQ/SMTP 实发、GitHub 下载、Nginx 真实安装或 WASM 运行。官方插件仓库真实 URL 目前未知，原型不会虚构。

真实项目源码尚未提供，本压缩包里的 `Plugin/` 只是建议的仓库目录模板；若需要把它应用到你的真实 GitHub 项目，应先提供代码仓库或把 ZIP 发给开发 Agent。
