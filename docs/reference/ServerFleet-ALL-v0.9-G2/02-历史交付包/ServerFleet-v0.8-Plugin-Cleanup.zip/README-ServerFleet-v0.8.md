# Server Fleet v0.8 · 当前交付索引

- 产品基线：`ServerFleet-Functional-Requirements-v0.8.md`（现行唯一生效产品需求规范）
- 后端设计：`ServerFleet-API-Contract-v0.8.yaml`（OpenAPI 3.1，未部署）
- 前端演示：`ServerFleet-v0.8.html`（纯前端模拟，不得输入任何真实密钥）
- 本版变更：`CHANGELOG-v0.8.md`
- 历史记录：`ServerFleet-Release-History-v0.2-v0.8.md`
- 质量检查：`QA-Results-v0.8.md`

六项 v0.8 需求已获批准；现阶段没有真实 Controller/Agent 后端。正式实现前应与既有架构 ADR 做一致性审查。在线预览站点：https://serverfleet-preview.vercel.app（Vercel 部署状态 READY；连接权限限制使工具无法独立获取该站点 HTTP 页面内容）

## 插件目录状态（文档修订 docs-r2）

已移除原型中六个示例/占位插件，当前 **0 个获批具体插件**。插件中心、仓库配置与通用插件生命周期仍保留。第一版插件清单将在后续单独审批。
