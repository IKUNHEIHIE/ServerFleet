# Server Fleet v0.9 — Xray 节点管理器获批版本

当前项目仍是**纯交互原型和设计契约**，没有实际 Controller/Agent 后端。第一版官方可选插件只批准 **Xray 节点管理器**，初始不随 Release 预装。

## 文件目录

- `ServerFleet-v0.9.html` — 可直接通过浏览器查看的前端交互原型。正式在线地址：`https://serverfleet-preview.vercel.app`（部署并确认版本后适用）。
- `ServerFleet-Functional-Requirements-v0.9.md` — 现行产品功能规范，完整继承 v0.8 并增加 FR-PLUGIN-XRAY-001 集成章节。
- `ServerFleet-API-Contract-v0.9.yaml` — 合并后的主 OpenAPI 设计契约（119 路径、151 操作、132 Schema）。
- `Plugin/index.json` — 官方插件目录结构的设计清单，只有 Xray 一个条目；`installable=false`。
- `Plugin/xray-manager/manifest.yaml` — 插件声明草案，非真实签名制品。
- `Plugin/xray-manager/FR-PLUGIN-XRAY-001.md` — 插件详细需求、风险与验收标准。
- `Plugin/xray-manager/Xray-Manager-OpenAPI.yaml` — 插件独立 API 草案（19 路径、23 操作）。
- `CHANGELOG-v0.9.md` — 本次批准变更。
- `QA-Results-v0.9.md` — 结构与模拟交互测试结果。
- `docs/previous-v0.8-archive.md` — 前版需求归档，不作为现行规范来源。

## 建议体验路径

打开「插件中心」，当前目录只有 Xray 节点管理器。点击模拟按需安装并启用后，侧栏才出现「Xray 节点管理器」。进入插件内，可以切换六个子页，在不连接任何真实服务器的情况下体验模拟节点安装、配置发布、用户创建和流量采样。

## 安全和开发提示

当前一切安装/更新/配置/流量为演示；**不得填写真实 UUID、API Key、私钥或有效代理配置**。后续真正实现前须完成 Xray 版本兼容、插件签名、最小权限、现有实例保护、配置回滚、流量计数校准及主控安全 ADR 一致性审查。
